#!/bin/bash

echo "Digite o número desejado: " 
read y

y=$((y+1))
echo "$y"

