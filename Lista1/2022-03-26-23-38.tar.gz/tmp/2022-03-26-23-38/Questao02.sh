#!/bin/bash

echo "Digite o nome do primeiro diretório: "
read primeiroDiretorio

echo "Digite o nome do primeiro diretório: " 
read segundoDiretorio

echo "*** Arquivos e diretórios do diretorio $primeiroDiretorio"
ls $primeiroDiretorio

echo "*** Arquivos e diretórios do diretorio $segundoDiretorio"
ls $segundoDiretorio


