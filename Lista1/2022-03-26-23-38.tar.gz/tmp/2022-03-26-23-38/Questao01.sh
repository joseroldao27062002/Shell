#!/bin/bash

echo "Ninguém tirará proveito de você se você for um inútil"
