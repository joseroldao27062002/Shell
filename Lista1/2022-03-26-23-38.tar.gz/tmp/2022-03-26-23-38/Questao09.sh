#!/bin/bash

echo "$(bc<<<$1^$2)" 
