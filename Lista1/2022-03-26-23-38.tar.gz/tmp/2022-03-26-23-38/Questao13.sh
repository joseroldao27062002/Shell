#!/bin/bash

soma=$(python -c "print($1 + $2 + $3)")
echo "soma: $soma"
