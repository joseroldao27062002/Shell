#!/bin/bash

echo "*** Arquivos e diretórios do diretorio $1"
ls $1

echo "*** Arquivos e diretórios do diretorio $2"
ls $2

